from setuptools import find_packages, setup

setup(
    name = 'Medical Chatbot',
    version= '0.0.0',
    author= 'Adithya Dev',
    author_email= 'susmidev1981@gmail.com',
    packages= find_packages(),
    install_requires = []

)